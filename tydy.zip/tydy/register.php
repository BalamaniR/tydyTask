<?php 
require_once('includes/header.php');
require_once('classes/loginClass.php');
error_reporting(0);

if($_REQUEST['btn_reg'] == 'Register'){
	$name  		= $_REQUEST['reg_name'];
	$email		= $_REQUEST['reg_email'];
	$pass  		= $_REQUEST['reg_password'];
	$restrict   = '/^(?=.*[a-z])(?=.*\\d).{8,}$/i'; 
	
	if($name == ''){
		$msg   = 'Name Cannot be null';
		$class = 'error';
	}else if($email == ''){
		$msg   = 'Email Cannot be null';
		$class = 'error';
	}else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  		$msg   = 'Invalid email format';
		$class = 'error';
	}else if($pass == ''){
		$msg   = 'Password Cannot be null';
		$class = 'error';
	}else if(!preg_match($restrict, $pass)) {
		$msg   = 'Password must contain at least 1 number/letter,8 character minimum requirement.';
		$class = 'error';
	}else{
		  $pwd         = hash('sha256', $pass);
		  $email_count = $logObj->validate_email_existance($email);
		  if($email_count['cnt'] == 0){
			  $res 	   = $logObj->add_registration_data($name,$email,$pwd);
			  if($res){		  	
	    		header('Location:http://localhost/tydy/login.php');
			  }	
		  }else{
		  	$msg   = 'This email ID already exists in our DB';
			$class = 'error';
		  }	
	}
}
?>
<style>
	.mydiv{
		width:600px;
		height:350px;
		}
</style> 
   
   
<div class="container mydiv">
	<form class="form-horizontal" role="form" method="POST">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <h2>Register New User</h2>
              
            </div>
        </div>
          <hr/>
          <div class="<?php echo $class;?>"><?php echo $msg; ?></div>
        <div class="row">
            <div class="col-md-2 field-label-responsive">
              <!--  <label for="name">Name</label>-->
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-user"></i></div>
                        <input type="text" name="reg_name" class="form-control" id="name"
                               placeholder="Enter your name" required autofocus>
                    </div>
                </div>
            </div>
         </div>   
          
        <div class="row">
            <div class="col-md-2 field-label-responsive">
               
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-at"></i></div>
                        <input type="email" name="reg_email" class="form-control" id="email"
                               placeholder="Enter your email" required autofocus>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2 field-label-responsive">
               
            </div>
            <div class="col-md-6">
                <div class="form-group has-danger">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-key"></i></div>
                        <input type="password" name="reg_password" class="form-control" id="password"
                               placeholder="Password" required>
                    </div>
                </div>
            </div>
         </div> 
        <div class="row ">
      
            <div class="col-md-3 field-label-responsive" style="margin-left:133px!important;">
               <a href="login.php">Login</a>
            </div>
            <div class="col-md-3">          
               <input type="submit" class="btn btn-success" name="btn_reg" value="Register">          
            </div>
            </div>
        </form>
       
  </div>
     
      

<script src="js/bootstrap.min.js"></script>
<?php 
require_once('includes/footer.php');
?>
