<?php 
require_once('includes/header.php');
require_once('classes/loginClass.php');
error_reporting(0);

if($_REQUEST['btn_log'] == 'Login'){
	
	$email  = $_REQUEST['log_email'];
	$pass	= $_REQUEST['log_password'];

	if($email == ''){
		$msg   = 'Email Cannot be null';
		$class = 'error';
	}else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  		$msg   = 'Invalid email format';
		$class = 'error';
	}else if($pass == ''){
		$msg   = 'Password Cannot be null';
		$class = 'error';
	}else{	
		$ecount =  $logObj->validate_email_existance($email);
		
		if($ecount['cnt'] < 0){
			$msg   = 'Email ID not a registered one';
			$class = 'error';
		}else{
			$pwd 	= hash('sha256', $pass);
			$res	= $logObj->validate_login_data($email,$pwd);
			$val    = mysqli_fetch_assoc($res);
			$count  = mysqli_num_rows($res);
				if($count > 0){
					#session_start();
					$_SESSION['user_id']   = $val['id'];
		            $_SESSION['uname']     = $val['reg_name'];
					header('Location:http://localhost/tydy/profile.php');			
				}else{
					$msg   = 'Email ID and Password Mismatch';
					$class = 'error';
				}		
		}
	}
}
?>
<style>
	.mydiv{
		width:500px;
		height:300px;
			margin-bottom: 100px;
	}
	
</style>   
<div class="container mydiv">
	<form class="form-horizontal" role="form" method="POST">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<h2>Login</h2>		  
			</div>
		</div>
		<hr/>
		<div class="<?php echo $class;?>"><?php echo $msg; ?></div>
		<div class="row">
			<div class="col-md-2 field-label-responsive"></div>
			<div class="col-md-6">
				<div class="form-group">
					<div class="input-group mb-2 mr-sm-2 mb-sm-0">
						<div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-at"></i></div>
						<input type="text" name="log_email" class="form-control" id="email"
					       placeholder="Enter your email" required autofocus autocomplete="off">
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-2 field-label-responsive"></div>
				<div class="col-md-6">
					<div class="form-group has-danger">
						<div class="input-group mb-2 mr-sm-2 mb-sm-0">
							<div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-key"></i></div>
							<input type="password" name="log_password" class="form-control" id="password"
						       placeholder="Password" required>
						</div>
					</div>
				</div>
		</div> 
		<div class="row ">
			<div class="col-md-5 field-label-responsive" >
			   <a href="forgotpass.php">Forgotpassword</a>
			</div>
			<div class="col-md-1">          
			   <input type="submit" class="btn btn-success" name="btn_log" value="Login">          
			</div>
		</div>
	</form>
</div>
     
      

<script src="js/bootstrap.min.js"></script>
<?php 
require_once('includes/footer.php');
?>
