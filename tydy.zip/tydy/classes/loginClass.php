<?php
include_once("dbClass.php");

class login extends myDBC{

	#function to insert registration details into register table
	
	public function add_registration_data($name,$email,$pwd){
		
		$db   = $this->mysqli;
		$sql  = "INSERT INTO register(reg_name,reg_email,reg_pwd,reg_date) VALUES(?,?,?,NOW())";	
		$stmt = $db->prepare($sql);
		$stmt->bind_param("sss",$name,$email,$pwd);
			if($stmt->execute()){
				$res = $stmt->insert_id;
			}else{
				$res = $stmt->error;
			}	
		return $res;	
		
	}
	
	#function to validate the email id is already existing or not
	
	public function validate_email_existance($email){
		
		$sql   = "SELECT count(*) as cnt FROM register WHERE  reg_email= '$email'";
 		$reslt = $this->runQuery($sql);
		$res   = mysqli_fetch_assoc($reslt);
		return $res;
	}	
	
	#function to validate the given email id and password is correct or not
	
	public function validate_login_data($email,$pwd){
	
	    $sql = "SELECT id,reg_name,reg_email FROM register WHERE reg_email= '$email' AND reg_pwd='$pwd'";
		$res = $this->runQuery($sql);
		return $res;
	}
	
	#function to update the profile details
	
	public function update_profile_details($email,$mobile,$gender,$dob,$marital,$address,$profile_photo,$user_id){
			
		$sql = "UPDATE register SET 				reg_email='$email',reg_contactno='$mobile',reg_gender='$gender',reg_dob='$dob',reg_marital_status='$marital',reg_address='$address',
				reg_photo_url='$profile_photo' WHERE  id='$user_id'";
		$res = $this->runQuery($sql);
		return $res;
	}
	
	#function to fetch user details based on session user id
	
	public function get_user_details($user_id){
		
			$sql ="SELECT * FROM register WHERE id='$user_id'";
			$reslt = $this->runQuery($sql);
			$res   = mysqli_fetch_assoc($reslt);
			return $res;
		
	}	
		
			
}


$logObj = new Login();	
?>
