<footer class="container-fluid text-center" style="margin-top: 50px;">
  <p>Copy rights@2018</p>
</footer>
  <script src="js/jquery.min.js"></script>