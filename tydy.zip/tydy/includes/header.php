<!DOCTYPE html>
<html lang="en">
<head>
  <title>tydy</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
  
<nav class="navbar navbar-inverse" style="background-color: white;">
  <div class="container-fluid">
	    <div class="navbar-header">    
	      <img src="images/tydy.png"/>
	    </div>    
    </div>
</nav>
<?php 
	error_reporting(0);
    session_start();   
   	if($_SESSION['user_id']!=''){
 ?>	
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
		      <li class="nav-item active">
		        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#">About Us</a>
		      </li>     
		      <li class="nav-item">
		        <a class="nav-link disabled" href="#">Services</a>
		      </li>
	    </ul>  
	    <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<?php	
			 echo "Welcome ".$_SESSION['uname']." . ";?>
	       	<a href="logout.php"><span style="color:red;font-weight:bold;">Logout</span></a>    
		</a>
 </div>
</nav>
  <?php }   ?>