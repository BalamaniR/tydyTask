-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2018 at 04:30 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tydy`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `reg_name` varchar(50) NOT NULL,
  `reg_email` varchar(150) NOT NULL,
  `reg_pwd` varchar(150) NOT NULL,
  `reg_contactno` varchar(10) NOT NULL,
  `reg_gender` enum('Male','Female') NOT NULL,
  `reg_dob` date NOT NULL,
  `reg_marital_status` varchar(20) NOT NULL,
  `reg_address` varchar(250) NOT NULL,
  `reg_photo_url` varchar(255) NOT NULL,
  `reg_status` tinyint(4) NOT NULL COMMENT '0->inactive,1->active',
  `reg_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `reg_name`, `reg_email`, `reg_pwd`, `reg_contactno`, `reg_gender`, `reg_dob`, `reg_marital_status`, `reg_address`, `reg_photo_url`, `reg_status`, `reg_date`) VALUES
(1, 'admin', 'admin@gmail.com', '22b7dec7305d63e2c769b0c9141114e69a194cc853b444c73b7be3a0771b628a', '9876442100', 'Male', '2018-05-29', 'Single', 'sadgsfghsdfhsdghshsdhsdf', 'profilePic/IMG_20161128_181946407.jpg', 0, '2018-05-12 13:12:59'),
(2, 'admin1', 'admin1@gmail.com', '22b7dec7305d63e2c769b0c9141114e69a194cc853b444c73b7be3a0771b628a', '9876543210', 'Male', '2018-05-01', 'Married', 'zzzzzzz', 'profilePic/dollar3.jpg', 0, '2018-05-12 19:55:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
