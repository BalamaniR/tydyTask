<?php 

require_once('includes/header.php');
if($_SESSION['user_id']!=''){
$user_id	= $_SESSION['user_id'];	
require_once('classes/loginClass.php');
error_reporting(1);
if($_REQUEST['btn_sub'] == 'Update Profile'){
	
	
	$email 		= $_REQUEST['prof_email'];
	$mobile 	= $_REQUEST['prof_pnone'];
	$dob 		= $_REQUEST['prof_dob'];
	$gender		= $_REQUEST['prof_gender'];
	$marital 	= $_REQUEST['prof_status'];
	$address	= $_REQUEST['prof_address'];
	$pattern 	=  '/[^0-9]/';
	if($email == ''){
		$msg   = 'Email Cannot be null';
		$class = 'error';
	}else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  		$msg   = 'Invalid email format';
		$class = 'error';
	}else if($mobile == ''){
		$msg   = 'Contact Number Cannot be null';
		$class = 'error';
	}/*
	else if(!preg_match( $pattern, $mobile )){
			$msg   = 'Invalid Contact Number';
			$class = 'error';		
		}*/
	else{
		$path          = "profilePic/";
		$profile_photo = $path . basename($_FILES['photo']['name']);
		if (file_exists($profile_photo)) {
			$msg   = 'Profile Image Already Exists';
			$class = 'error';
		}else{
			move_uploaded_file($_FILES['photo']['tmp_name'], $profile_photo);		
		}		
		$res    = $logObj->update_profile_details($email,$mobile,$gender,$dob,$marital,$address,$profile_photo,$user_id);
	}
}
$result = $logObj->get_user_details($user_id);	
?>

  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }



  </style>
</head>
<body>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
	<div class="carousel-inner" role="listbox" style="border:1px solid grey; margin-left:220px;width:900px;margin-top:30px;">
		<h3 align="center" style="margin:10px;color:blue;font-weight:bold;">My Profile</h3>
		<hr/>
		<div class="<?php echo $class;?>" style="margin-left:350px;margin-bottom: 20px;"><?php echo $msg; ?></div>
		<form name="frm_profile" method="POST" enctype="multipart/form-data">
			<div class="row">
					<div class="mx-auto col-sm-3">
					<?php 
					if($result['reg_photo_url'] != ''){
					$url = $result['reg_photo_url'];
					}else{
						$url ='images/user.png';
					}
					?>
					<img src="<?php echo $url;?>" width="100%" height:100px;>
					<caption><h3 align="center"><?php echo "Bala"; ?></h3></caption>	
	 					<div class="form-group row" style="margin-top:10px;">
							<label class="col-lg-4 col-form-label form-control-label">Photo</label>
							<div class="col-lg-8" style="margin-top: 4px;">
								<input type="file" name="photo">
							</div>
						</div>
				</div>
				<div class="mx-auto col-sm-6">
					<div class="form-group row">
						<label class="col-lg-4 col-form-label form-control-label"><span class="error">*</span>Email</label>
						<div class="col-lg-8">
							<input class="form-control" type="text" name="prof_email" value="<?php echo $result['reg_email'];?>">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-lg-4 col-form-label form-control-label"><span class="error">*</span>Contact No</label>
						<div class="col-lg-8">
							<input class="form-control" type="number" name="prof_pnone" value="<?php echo $result['reg_contactno'];?>" maxlength="12">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-lg-4 col-form-label form-control-label">DateOfBirth</label>
						<div class="col-lg-8">
							<input class="form-control" type="date" name="prof_dob" value="<?php echo $result['reg_dob'];?>">
						</div> 
					</div>
					<div class="form-group row">
						<label class="col-lg-4 col-form-label form-control-label">Marital Status</label>
						<div class="col-lg-8">
					 		<div class="form-check form-check-inline">
					 			<label class="form-check-label">
								<input class="form-check-input" type="radio" name="prof_gender" id="inlineRadio1"  <?php if($result['reg_gender']=="Male") echo "checked";?> value="Male"> Male
					  			</label>
							</div>
							<div class="form-check form-check-inline">
							 	<label class="form-check-label">
								<input class="form-check-input" type="radio" name="prof_gender" id="inlineRadio2" <?php if($result['reg_gender']=="Female") echo "checked";?> value="Female"> Female
							  	</label>
							</div>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-lg-4 col-form-label form-control-label">Marital Status</label>
							<div class="col-lg-8">
								<select name="prof_status" class="form-control">
									<option value="">--Select Status--</option>
									<option <?php if($result['reg_marital_status']== 'Single'){ echo 'selected="selected"';}?>Value="Single">Single</option>
									<option <?php if($result['reg_marital_status']=='Married'){echo 'selected="selected"';}?> value="Married">Married</option>
									<option <?php if($result['reg_marital_status']== 'Widow/Divorced'){ echo 'selected="selected"';} ?> value="other">Widow/Divorced</option>
								</select>
							</div> 
					</div>
					<div class="form-group row">
						<label class="col-lg-4 col-form-label form-control-label">Address</label>
						<div class="col-lg-8">
							<input class="form-control" type="text" name="prof_address" value="<?php echo $result['reg_address'];?>" maxlength="600">
						</div>
					</div>
					<div style="margin-bottom:50px;float:right;">
					 	<input type="submit" name="btn_sub" value="Update Profile" class="btn btn-info">
					</div>					
				</div>      	
 		</div>
	</form>  
</div>
</body>
</html>
<script src="js/bootstrap.min.js"></script>
<?php }else{
	header('Location:http://localhost/tydy/login.php');		
 }?>
<?php require_once('includes/footer.php'); ?>