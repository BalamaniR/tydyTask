<?php 
require_once('includes/header.php');
?>

<style>
	.mydiv{
		width:600px;
		height:200px;
		margin-bottom: 200px;
	}
	
</style>   
   
   
   
   
<div class="container mydiv">
	<form class="form-horizontal" role="form" method="POST" action="/register">
        <div class="row">
           
            <div class="col-md-12" style="margin-left: 100px;"> 
                <h2>Forgot Password</h2>
              
            </div>
        </div>
          <hr/>
        
        <div class="row">
            <div class="col-md-2 field-label-responsive">
               <!-- <label for="email">E-Mail Address</label>-->
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-at"></i></div>
                        <input type="text" name="email" class="form-control" id="email"
                               placeholder="Enter your email" required autofocus>
                    </div>
                </div>
            </div>
        </div>
        
         <div class="row ">
                  
               <input type="submit" class="btn btn-info" name="btn_reg" value="Submit" style="margin-left:300px;">          
            
            </div>
       
        </form>
       
  </div>
     
      

<script src="js/bootstrap.min.js"></script>
<?php 
require_once('includes/footer.php');
?>
